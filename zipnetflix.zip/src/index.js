import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
import { initializeApp } from "firebase/app";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import { getFirestore,collection ,getDocs,getDoc} from "firebase/firestore";

const firebaseApp = initializeApp({
  apiKey: "AIzaSyApN8NwIZDhF6aYgbu-OEy1B2uQzDs0qP4",
  authDomain: "netflix-clone-50399.firebaseapp.com",
  projectId: "netflix-clone-50399",
  storageBucket: "netflix-clone-50399.appspot.com",
  messagingSenderId: "179315623655",
  appId: "1:179315623655:web:ec34c582bee06983188442",
  measurementId: "G-E611E61PPS",
});
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);
db.collection('todos').getDocs();
const todosCol= collection(db,'todos');
const snapshot=getDocs(todosCol);


auth.onAuthStateChanged(user =>{
  
})
onAuthStateChanged(auth,user =>{
  if(user != null){
    console.log("log in");
  }
  else{
    console.log("no user");
  }
});
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
